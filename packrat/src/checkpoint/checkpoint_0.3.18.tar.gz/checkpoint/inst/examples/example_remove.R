checkpointArchives()
\dontrun{
checkpointRemove("2016-10-01")
}

